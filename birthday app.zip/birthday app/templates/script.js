// Add event listeners to navigation links
document.querySelectorAll('header nav a').forEach((link) => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        // Add logic to handle navigation link clicks
    });
});

// Add event listeners to CTA buttons
document.querySelectorAll('.get-started,.learn-more').forEach((button) => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        // Add logic to handle CTA button clicks
    });
});